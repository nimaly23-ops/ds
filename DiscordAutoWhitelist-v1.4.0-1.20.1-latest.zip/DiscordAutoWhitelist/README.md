# DiscordAutoWhitelist — Plugin Auto-Whitelist Minecraft via Discord (1.20.1 – Terbaru)

**DiscordAutoWhitelist** menghubungkan server Minecraft kamu (Paper/Spigot **1.20.1 hingga versi terbaru**, Online-Mode, Cracked/Offline-Mode, maupun Geyser/Bedrock) langsung ke **Bot Discord** bawaan (JDA 5.5.1 — tanpa perlu DiscordSRV!) sehingga pemain bisa mendaftar dan langsung otomatis masuk whitelist server.

---

## Fitur Utama

1. **3 Cara Daftar Auto-Whitelist di Discord**
   - **Panel Tombol + Popup Modal**: Admin ketik `/whitelist-panel` di channel Discord → pemain klik tombol **"✅ Daftar Whitelist"** → isi username Minecraft → langsung otomatis masuk whitelist!
   - **Slash Command**: Pemain ketik `/whitelist <username>` di Discord.
   - **Ketik Langsung di Channel Whitelist**: Jika `whitelist-channel-id` diisi dan `allow-direct-channel-message: true`, pemain cukup ketik username mereka di channel tersebut.
2. **Kompatibel Online-Mode, Cracked, & Bedrock (Geyser)**
   - Menjalankan `whitelist add` sekaligus memverifikasi langsung saat `PlayerLoginEvent` agar akun offline/Bedrock (prefix `.`) tetap bisa masuk tanpa error lookup UUID.
3. **Anti-Alt, Auto-Role, & Auto-Unwhitelist**
   - Batas maksimal akun Minecraft per 1 akun Discord (`max-accounts-per-discord: 1`).
   - Otomatis memberi Role Discord (`whitelisted-role-id`) setelah berhasil daftar.
   - Otomatis mencabut whitelist jika member keluar dari server Discord (`auto-remove-on-leave: true`).

---

## Cara Setup Bot Discord (2 Menit)

1. Buka [Discord Developer Portal](https://discord.com/developers/applications) → **New Application** → masuk menu **Bot**.
2. Aktifkan **Server Members Intent** dan **Message Content Intent**, lalu klik **Reset Token** dan salin tokennya.
3. Masuk menu **OAuth2 → URL Generator**, centang `bot` dan `applications.commands`, lalu pilih permission `Send Messages`, `Read Message History`, `Add Reactions`, `Manage Roles` → buka link invite ke server Discord kamu.
4. Tempel token di `plugins/DiscordAutoWhitelist/config.yml` (`bot-token`), isi `guild-id` & `whitelist-channel-id`, lalu jalankan `/dcwl reload` di server Minecraft.

---

## Cara Compile Menjadi `.jar` (GitHub Actions)

1. Upload seluruh isi folder `DiscordAutoWhitelist/` ke repository GitHub (pastikan `pom.xml`, `src/`, dan `.github/workflows/build.yml` ada di root repo).
2. Buka tab **Actions** → klik **Build DiscordAutoWhitelist JAR** → unduh **`DiscordAutoWhitelist-JAR`** di bagian **Artifacts**.
3. Masukkan `DiscordAutoWhitelist-1.0.0.jar` ke folder `plugins/` server dan restart.
