package com.discordwhitelist.manager;

import com.discordwhitelist.DiscordWhitelistPlugin;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

public class WhitelistManager {

    private static final Pattern JAVA_NAME = Pattern.compile("^[a-zA-Z0-9_]{3,16}$");
    private static final Pattern BEDROCK_NAME = Pattern.compile("^[._]?[a-zA-Z0-9_ ]{3,16}$");

    public enum AddStatus {
        SUCCESS,
        INVALID_NAME,
        ALREADY_WHITELISTED,
        ALREADY_ATTEMPTED
    }

    private final DiscordWhitelistPlugin plugin;
    private final File dataFile;
    private FileConfiguration dataConfig;

    private final Map<String, String> whitelistedNames = new LinkedHashMap<>();
    private final Map<String, String> nameToDiscord = new LinkedHashMap<>();
    private final Map<String, String> attemptedDiscord = new LinkedHashMap<>();
    private String panelMessageId = "";

    public WhitelistManager(DiscordWhitelistPlugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "whitelist-data.yml");
        load();
    }

    public synchronized String getPanelMessageId() {
        return panelMessageId;
    }

    public synchronized void setPanelMessageId(String messageId) {
        this.panelMessageId = messageId != null ? messageId : "";
        save();
    }

    public boolean isValidUsername(String username) {
        if (username == null) {
            return false;
        }
        String trimmed = username.trim();
        if (plugin.getConfig().getBoolean("whitelist.allow-bedrock-prefix", true)) {
            return JAVA_NAME.matcher(trimmed).matches() || BEDROCK_NAME.matcher(trimmed).matches();
        }
        return JAVA_NAME.matcher(trimmed).matches();
    }

    public synchronized boolean isWhitelisted(String username) {
        if (username == null) {
            return false;
        }
        return whitelistedNames.containsKey(username.toLowerCase(Locale.ROOT));
    }

    public synchronized boolean hasAttempted(String discordId) {
        if (discordId == null || "CONSOLE".equals(discordId)) {
            return false;
        }
        return attemptedDiscord.containsKey(discordId);
    }

    public synchronized void markRejectedAttempt(String discordId, String mcUsername) {
        if (discordId == null || "CONSOLE".equals(discordId)) {
            return;
        }
        attemptedDiscord.put(discordId, "REJECTED:" + (mcUsername != null ? mcUsername.trim() : "-"));
        save();
    }

    public synchronized boolean resetAttempt(String discordId) {
        if (discordId == null) {
            return false;
        }
        boolean removed = attemptedDiscord.remove(discordId) != null;
        if (removed) {
            save();
        }
        return removed;
    }

    public synchronized List<String> getAccountsForDiscord(String discordId) {
        List<String> accounts = new ArrayList<>();
        for (Map.Entry<String, String> entry : nameToDiscord.entrySet()) {
            if (discordId.equals(entry.getValue())) {
                accounts.add(whitelistedNames.get(entry.getKey()));
            }
        }
        return accounts;
    }

    public synchronized List<String> getAllWhitelistedNames() {
        return Collections.unmodifiableList(new ArrayList<>(whitelistedNames.values()));
    }

    public synchronized AddStatus addWhitelist(String rawUsername, String discordId, boolean bypassAttemptCheck) {
        if (rawUsername == null) {
            return AddStatus.INVALID_NAME;
        }
        String username = rawUsername.trim();
        if (!isValidUsername(username)) {
            return AddStatus.INVALID_NAME;
        }

        if (!bypassAttemptCheck && plugin.getConfig().getBoolean("whitelist.one-attempt-only", true)
                && hasAttempted(discordId)) {
            return AddStatus.ALREADY_ATTEMPTED;
        }

        String lower = username.toLowerCase(Locale.ROOT);
        if (whitelistedNames.containsKey(lower)) {
            return AddStatus.ALREADY_WHITELISTED;
        }

        whitelistedNames.put(lower, username);
        nameToDiscord.put(lower, discordId != null ? discordId : "CONSOLE");
        if (discordId != null && !"CONSOLE".equals(discordId)) {
            attemptedDiscord.put(discordId, "APPROVED:" + username);
        }
        save();

        Bukkit.getScheduler().runTask(plugin, () ->
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "whitelist add " + username));

        return AddStatus.SUCCESS;
    }

    public synchronized boolean removeWhitelist(String rawUsername) {
        if (rawUsername == null) {
            return false;
        }
        String lower = rawUsername.trim().toLowerCase(Locale.ROOT);
        String original = whitelistedNames.remove(lower);
        nameToDiscord.remove(lower);
        if (original == null) {
            return false;
        }
        save();

        Bukkit.getScheduler().runTask(plugin, () -> {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "whitelist remove " + original);
            Player online = Bukkit.getPlayerExact(original);
            if (online != null && !online.isOp()) {
                online.kickPlayer(plugin.getFormattedKickMessage());
            }
        });
        return true;
    }

    public synchronized List<String> removeAllForDiscord(String discordId) {
        List<String> accounts = getAccountsForDiscord(discordId);
        for (String acc : accounts) {
            removeWhitelist(acc);
        }
        return accounts;
    }

    private void load() {
        if (!dataFile.exists()) {
            dataConfig = new YamlConfiguration();
            return;
        }
        dataConfig = YamlConfiguration.loadConfiguration(dataFile);
        this.panelMessageId = dataConfig.getString("panel-message-id", "");

        ConfigurationSection sec = dataConfig.getConfigurationSection("players");
        if (sec != null) {
            for (String lower : sec.getKeys(false)) {
                String orig = sec.getString(lower + ".name", lower);
                String dcId = sec.getString(lower + ".discord-id", "CONSOLE");
                whitelistedNames.put(lower, orig);
                nameToDiscord.put(lower, dcId);
            }
        }
        ConfigurationSection att = dataConfig.getConfigurationSection("attempts");
        if (att != null) {
            for (String dcId : att.getKeys(false)) {
                attemptedDiscord.put(dcId, att.getString(dcId, "APPROVED"));
            }
        }
    }

    public synchronized void save() {
        dataConfig.set("panel-message-id", panelMessageId);
        dataConfig.set("players", null);
        for (Map.Entry<String, String> entry : whitelistedNames.entrySet()) {
            String lower = entry.getKey();
            dataConfig.set("players." + lower + ".name", entry.getValue());
            dataConfig.set("players." + lower + ".discord-id", nameToDiscord.getOrDefault(lower, "CONSOLE"));
        }
        dataConfig.set("attempts", null);
        for (Map.Entry<String, String> entry : attemptedDiscord.entrySet()) {
            dataConfig.set("attempts." + entry.getKey(), entry.getValue());
        }
        try {
            if (!plugin.getDataFolder().exists()) {
                plugin.getDataFolder().mkdirs();
            }
            dataConfig.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().warning("Gagal menyimpan whitelist-data.yml: " + e.getMessage());
        }
    }
}
