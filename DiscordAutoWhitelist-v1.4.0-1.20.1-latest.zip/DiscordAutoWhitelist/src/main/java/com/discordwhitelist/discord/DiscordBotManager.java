package com.discordwhitelist.discord;

import com.discordwhitelist.DiscordWhitelistPlugin;
import com.discordwhitelist.manager.WhitelistManager;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.entities.Activity;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Role;
import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;
import net.dv8tion.jda.api.entities.emoji.Emoji;
import net.dv8tion.jda.api.events.guild.member.GuildMemberRemoveEvent;
import net.dv8tion.jda.api.events.interaction.ModalInteractionEvent;
import net.dv8tion.jda.api.events.interaction.component.ButtonInteractionEvent;
import net.dv8tion.jda.api.events.session.ReadyEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.interactions.components.buttons.Button;
import net.dv8tion.jda.api.interactions.components.text.TextInput;
import net.dv8tion.jda.api.interactions.components.text.TextInputStyle;
import net.dv8tion.jda.api.interactions.modals.Modal;
import net.dv8tion.jda.api.interactions.modals.ModalMapping;
import net.dv8tion.jda.api.requests.GatewayIntent;
import org.bukkit.Bukkit;

import java.awt.Color;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * 100% Berbasis Tombol & Modal Discord (TANPA COMMAND):
 * - Panel tombol "Daftar Whitelist" otomatis dikirim ke whitelist-channel-id
 * - Log Private Admin (jawaban lengkap + tombol Reset / Cabut WL) -> log-channel-id
 * - Log Publik Player WL (nama MC + mention Discord, tanpa bocorkan jawaban) -> public-wl-log-channel-id
 */
public class DiscordBotManager extends ListenerAdapter {

    private static final String BTN_REGISTER = "dcwl_open_rp_modal";
    private static final String BTN_RESET_PREFIX = "dcwl_reset:";
    private static final String BTN_REVOKE_PREFIX = "dcwl_revoke:";
    private static final String MODAL_REGISTER = "dcwl_submit_rp_modal";

    private static final String INPUT_MC_NAME = "rp_mc_name";
    private static final String INPUT_RP_DURATION = "rp_duration";
    private static final String INPUT_VOICE_CHAT = "rp_voice_chat";
    private static final String INPUT_CAN_SPEAK_RP = "rp_can_speak";
    private static final String INPUT_OBEY_RULES = "rp_obey_rules";

    private final DiscordWhitelistPlugin plugin;
    private JDA jda;

    public DiscordBotManager(DiscordWhitelistPlugin plugin) {
        this.plugin = plugin;
    }

    public void startAsync() {
        String token = plugin.getConfig().getString("discord.bot-token", "").trim();
        if (token.isEmpty() || token.equals("MASUKKAN_TOKEN_BOT_DISCORD_DISINI")) {
            plugin.getLogger().warning("Token Bot Discord belum diisi di config.yml! Isi bot-token dan whitelist-channel-id lalu restart server.");
            return;
        }

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                String activityText = plugin.getConfig().getString("discord.bot-activity", "Verifikasi Whitelist RP");
                this.jda = JDABuilder.createDefault(token)
                        .enableIntents(GatewayIntent.GUILD_MEMBERS)
                        .setActivity(Activity.playing(activityText))
                        .addEventListeners(this)
                        .build();
                plugin.getLogger().info("Menghubungkan bot Discord Verifikasi Whitelist...");
            } catch (Exception e) {
                plugin.getLogger().severe("Gagal menghubungkan bot Discord: " + e.getMessage());
            }
        });
    }

    public void shutdown() {
        if (jda != null) {
            try {
                jda.shutdownNow();
            } catch (Exception ignored) {
            }
            jda = null;
        }
    }

    @Override
    public void onReady(ReadyEvent event) {
        plugin.getLogger().info("Bot Discord online sebagai: " + event.getJDA().getSelfUser().getAsTag());
        ensureVerificationPanelExists(event.getJDA());
    }

    private void ensureVerificationPanelExists(JDA api) {
        String channelId = plugin.getConfig().getString("discord.whitelist-channel-id", "").trim();
        if (channelId.isEmpty()) {
            plugin.getLogger().warning("discord.whitelist-channel-id belum diisi di config.yml!");
            return;
        }

        TextChannel channel = api.getTextChannelById(channelId);
        if (channel == null) {
            plugin.getLogger().warning("Channel Discord dengan ID " + channelId + " tidak ditemukan.");
            return;
        }

        String savedMsgId = plugin.getWhitelistManager().getPanelMessageId();
        if (savedMsgId != null && !savedMsgId.isEmpty()) {
            channel.retrieveMessageById(savedMsgId).queue(
                    existing -> plugin.getLogger().info("Panel Verifikasi Whitelist sudah aktif di #" + channel.getName()),
                    missing -> sendVerificationPanel(channel)
            );
        } else {
            sendVerificationPanel(channel);
        }
    }

    private void sendVerificationPanel(TextChannel channel) {
        EmbedBuilder embed = new EmbedBuilder()
                .setTitle("✦ VERIFIKASI & PENDAFTARAN WHITELIST RP")
                .setDescription("Belum terdaftar whitelist? Klik tombol **Daftar Whitelist** di bawah ini untuk verifikasi.\n\n"
                        + "**Syarat Wajib:**\n"
                        + "• Setiap akun Discord hanya bisa mendaftar **1x**\n"
                        + "• Wajib memakai **Voice Chat**\n"
                        + "• Wajib **bisa berbicara / RP**\n"
                        + "• Wajib **bersedia menaati semua aturan server**\n\n"
                        + "Jika semua syarat terpenuhi, akun Minecraft kamu **langsung otomatis di-whitelist**!")
                .setColor(new Color(88, 101, 242))
                .setFooter("DiscordAutoWhitelist • Jawab dengan jujur (1x kesempatan)")
                .setTimestamp(Instant.now());

        channel.sendMessageEmbeds(embed.build())
                .addActionRow(Button.success(BTN_REGISTER, "Daftar Whitelist").withEmoji(Emoji.fromUnicode("📝")))
                .queue(msg -> {
                    plugin.getWhitelistManager().setPanelMessageId(msg.getId());
                    plugin.getLogger().info("Panel Verifikasi Whitelist otomatis dikirim ke #" + channel.getName());
                }, err -> plugin.getLogger().warning("Gagal mengirim panel ke #" + channel.getName() + ": " + err.getMessage()));
    }

    @Override
    public void onButtonInteraction(ButtonInteractionEvent event) {
        String id = event.getComponentId();

        if (BTN_REGISTER.equals(id)) {
            if (isBlockedByOneAttempt(event.getMember(), event.getUser().getId())) {
                event.reply("❌ Kamu sudah menggunakan **1x kesempatan pendaftaran**! Akun Discord hanya bisa mendaftar 1 kali.").setEphemeral(true).queue();
                return;
            }
            event.replyModal(buildRpModal()).queue();
            return;
        }

        if (id.startsWith(BTN_RESET_PREFIX)) {
            if (event.getMember() == null || !event.getMember().hasPermission(Permission.ADMINISTRATOR)) {
                event.reply("❌ Hanya Admin yang dapat mereset kesempatan daftar.").setEphemeral(true).queue();
                return;
            }
            String targetDiscordId = id.substring(BTN_RESET_PREFIX.length());
            plugin.getWhitelistManager().resetAttempt(targetDiscordId);
            event.editMessage("✅ Kesempatan daftar milik <@" + targetDiscordId + "> telah direset oleh " + event.getUser().getAsMention() + ".")
                    .setComponents().queue();
            return;
        }

        if (id.startsWith(BTN_REVOKE_PREFIX)) {
            if (event.getMember() == null || !event.getMember().hasPermission(Permission.ADMINISTRATOR)) {
                event.reply("❌ Hanya Admin yang dapat mencabut whitelist.").setEphemeral(true).queue();
                return;
            }
            String mcName = id.substring(BTN_REVOKE_PREFIX.length());
            plugin.getWhitelistManager().removeWhitelist(mcName);
            event.editMessage("🚫 Whitelist `" + mcName + "` telah dicabut oleh " + event.getUser().getAsMention() + ".")
                    .setComponents().queue();
        }
    }

    @Override
    public void onModalInteraction(ModalInteractionEvent event) {
        if (!MODAL_REGISTER.equals(event.getModalId())) {
            return;
        }

        String discordId = event.getUser().getId();
        Member member = event.getMember();
        Guild guild = event.getGuild();

        if (isBlockedByOneAttempt(member, discordId)) {
            event.reply("❌ Kamu sudah menggunakan **1x kesempatan pendaftaran**!").setEphemeral(true).queue();
            return;
        }

        String mcName = getModalValue(event, INPUT_MC_NAME);
        String rpDuration = getModalValue(event, INPUT_RP_DURATION);
        String voiceChat = getModalValue(event, INPUT_VOICE_CHAT);
        String canSpeakRp = getModalValue(event, INPUT_CAN_SPEAK_RP);
        String obeyRules = getModalValue(event, INPUT_OBEY_RULES);

        List<String> failed = new ArrayList<>();

        if (!plugin.getWhitelistManager().isValidUsername(mcName)) {
            failed.add("Nama MC `" + mcName + "` tidak valid (harus 3–16 karakter huruf/angka/underscore).");
        } else if (plugin.getWhitelistManager().isWhitelisted(mcName)) {
            failed.add("Nama MC `" + mcName + "` sudah terdaftar di whitelist.");
        }

        if (rpDuration.isBlank()) {
            failed.add("Kolom **Berapa lama ikut RP** wajib diisi.");
        }

        if (!isYesAnswer(voiceChat)) {
            failed.add("Wajib memakai **Voice Chat** (jawaban kamu: `" + voiceChat + "`).");
        }

        if (!isYesAnswer(canSpeakRp)) {
            failed.add("Wajib **bisa berbicara / RP** (jawaban kamu: `" + canSpeakRp + "`).");
        }

        if (!isYesAnswer(obeyRules)) {
            failed.add("Wajib **bersedia menaati semua aturan** (jawaban kamu: `" + obeyRules + "`).");
        }

        if (!failed.isEmpty()) {
            boolean isAdmin = member != null && member.hasPermission(Permission.ADMINISTRATOR);
            if (!isAdmin && plugin.getConfig().getBoolean("whitelist.one-attempt-only", true)) {
                plugin.getWhitelistManager().markRejectedAttempt(discordId, mcName);
            }

            StringBuilder reply = new StringBuilder("❌ **Verifikasi Ditolak — Kamu tidak memenuhi syarat whitelist:**\n");
            for (String f : failed) {
                reply.append("• ").append(f).append("\n");
            }
            reply.append("\n⚠️ *Kesempatan pendaftaran (1x per akun) telah terpakai.*");
            event.reply(reply.toString()).setEphemeral(true).queue();

            sendAdminLog(guild, false, discordId, mcName, rpDuration, voiceChat, canSpeakRp, obeyRules,
                    String.join(" | ", failed));
            return;
        }

        boolean isAdmin = member != null && member.hasPermission(Permission.ADMINISTRATOR);
        WhitelistManager.AddStatus status = plugin.getWhitelistManager().addWhitelist(mcName, discordId, isAdmin);
        if (status == WhitelistManager.AddStatus.SUCCESS) {
            giveRoleIfConfigured(guild, member);
            event.reply("✅ **Verifikasi Berhasil!**\nUsername **" + mcName
                    + "** telah otomatis masuk **Whitelist Server Minecraft** dan sekarang bisa langsung join!").setEphemeral(true).queue();

            // 1. Kirim detail lengkap ke channel log private admin
            sendAdminLog(guild, true, discordId, mcName, rpDuration, voiceChat, canSpeakRp, obeyRules,
                    "Lolos semua syarat (Auto-Whitelist)");

            // 2. Kirim pengumuman bersih ke channel Player Logs WL publik (tanpa bocorkan jawaban private!)
            sendPublicPlayerLog(guild, member, discordId, mcName);
        } else {
            event.reply("❌ Gagal memproses whitelist (`" + status.name() + "`).").setEphemeral(true).queue();
        }
    }

    @Override
    public void onGuildMemberRemove(GuildMemberRemoveEvent event) {
        if (!plugin.getConfig().getBoolean("discord.auto-remove-on-leave", true)) {
            return;
        }
        List<String> removed = plugin.getWhitelistManager().removeAllForDiscord(event.getUser().getId());
        if (!removed.isEmpty()) {
            plugin.getLogger().info("Auto-unwhitelist karena keluar Discord (" + event.getUser().getName() + "): " + removed);
        }
    }

    private Modal buildRpModal() {
        return Modal.create(MODAL_REGISTER, "Verifikasi Pendaftaran Whitelist RP")
                .addActionRow(TextInput.create(INPUT_MC_NAME, "Nama MC", TextInputStyle.SHORT)
                        .setPlaceholder("Contoh: Steve atau .SteveBedrock")
                        .setRequired(true)
                        .setMinLength(3)
                        .setMaxLength(16)
                        .build())
                .addActionRow(TextInput.create(INPUT_RP_DURATION, "Berapa lama ikut RP?", TextInputStyle.SHORT)
                        .setPlaceholder("Contoh: 6 bulan / 1 tahun / Baru mulai")
                        .setRequired(true)
                        .setMaxLength(50)
                        .build())
                .addActionRow(TextInput.create(INPUT_VOICE_CHAT, "Pakai Voice Chat? (iya / tidak)", TextInputStyle.SHORT)
                        .setPlaceholder("Ketik: iya atau tidak")
                        .setRequired(true)
                        .setMaxLength(15)
                        .build())
                .addActionRow(TextInput.create(INPUT_CAN_SPEAK_RP, "Bisa berbicara / RP? (iya / tidak)", TextInputStyle.SHORT)
                        .setPlaceholder("Ketik: iya atau tidak")
                        .setRequired(true)
                        .setMaxLength(15)
                        .build())
                .addActionRow(TextInput.create(INPUT_OBEY_RULES, "Bersedia menaati semua aturan? (iya / tidak)", TextInputStyle.SHORT)
                        .setPlaceholder("Ketik: iya atau tidak")
                        .setRequired(true)
                        .setMaxLength(15)
                        .build())
                .build();
    }

    private boolean isYesAnswer(String raw) {
        if (raw == null) {
            return false;
        }
        String norm = raw.trim().toLowerCase(Locale.ROOT);
        return norm.equals("iya") || norm.equals("ya") || norm.equals("yes") || norm.equals("bersedia") || norm.equals("bisa");
    }

    private boolean isBlockedByOneAttempt(Member member, String discordId) {
        if (!plugin.getConfig().getBoolean("whitelist.one-attempt-only", true)) {
            return false;
        }
        if (member != null && member.hasPermission(Permission.ADMINISTRATOR)) {
            return false;
        }
        return plugin.getWhitelistManager().hasAttempted(discordId);
    }

    private String getModalValue(ModalInteractionEvent event, String fieldId) {
        ModalMapping mapping = event.getValue(fieldId);
        return mapping != null ? mapping.getAsString().trim() : "";
    }

    /**
     * Log Private Admin (berisi seluruh jawaban formulir + tombol Reset / Cabut WL).
     */
    private void sendAdminLog(Guild guild, boolean approved, String discordId, String mcName,
                              String rpDuration, String voiceChat, String canSpeakRp, String obeyRules, String note) {
        if (guild == null) {
            return;
        }
        String logChId = plugin.getConfig().getString("discord.log-channel-id", "").trim();
        if (logChId.isEmpty()) {
            return;
        }
        TextChannel ch = guild.getTextChannelById(logChId);
        if (ch == null) {
            return;
        }
        EmbedBuilder embed = new EmbedBuilder()
                .setTitle(approved ? "✅ Verifikasi RP Lolos (Auto-WL)" : "❌ Verifikasi RP Ditolak")
                .addField("Discord", "<@" + discordId + ">", true)
                .addField("Nama MC", "`" + mcName + "`", true)
                .addField("Lama Ikut RP", rpDuration.isEmpty() ? "-" : rpDuration, true)
                .addField("Pakai Voice Chat", voiceChat, true)
                .addField("Bisa Bicara / RP", canSpeakRp, true)
                .addField("Taat Aturan", obeyRules, true)
                .addField("Catatan", note, false)
                .setColor(approved ? new Color(34, 197, 94) : new Color(239, 68, 68))
                .setTimestamp(Instant.now());

        if (approved) {
            ch.sendMessageEmbeds(embed.build())
                    .addActionRow(Button.danger(BTN_REVOKE_PREFIX + mcName, "Cabut Whitelist").withEmoji(Emoji.fromUnicode("🚫")))
                    .queue(null, err -> {});
        } else {
            ch.sendMessageEmbeds(embed.build())
                    .addActionRow(Button.secondary(BTN_RESET_PREFIX + discordId, "Reset 1x Kesempatan").withEmoji(Emoji.fromUnicode("🔄")))
                    .queue(null, err -> {});
        }
    }

    /**
     * Log Publik Player WL di channel terpisah (hanya nama MC & mention Discord, tanpa bocorkan jawaban private).
     */
    private void sendPublicPlayerLog(Guild guild, Member member, String discordId, String mcName) {
        if (guild == null) {
            return;
        }
        String pubChId = plugin.getConfig().getString("discord.public-wl-log-channel-id", "").trim();
        if (pubChId.isEmpty()) {
            return;
        }
        TextChannel ch = guild.getTextChannelById(pubChId);
        if (ch == null) {
            return;
        }

        int totalWhitelisted = plugin.getWhitelistManager().getAllWhitelistedNames().size();
        EmbedBuilder embed = new EmbedBuilder()
                .setTitle("✦ PLAYER BARU TERDAFTAR WHITELIST")
                .setDescription("<@" + discordId + "> telah lolos verifikasi dan resmi masuk whitelist server!")
                .addField("Username Minecraft", "`" + mcName + "`", true)
                .addField("Status", "✅ Terverifikasi", true)
                .setColor(new Color(34, 197, 94))
                .setFooter("Total Player Whitelist: " + totalWhitelisted)
                .setTimestamp(Instant.now());

        if (member != null) {
            embed.setThumbnail(member.getEffectiveAvatarUrl());
        }

        ch.sendMessageEmbeds(embed.build()).queue(null, err -> {});
    }

    private void giveRoleIfConfigured(Guild guild, Member member) {
        if (guild == null || member == null) {
            return;
        }
        String roleId = plugin.getConfig().getString("discord.whitelisted-role-id", "").trim();
        if (roleId.isEmpty()) {
            return;
        }
        Role role = guild.getRoleById(roleId);
        if (role != null) {
            guild.addRoleToMember(member, role).queue(null, err -> {});
        }
    }
}
