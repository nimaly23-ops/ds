package com.discordwhitelist.listener;

import com.discordwhitelist.DiscordWhitelistPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerLoginEvent;

/**
 * Menegakkan whitelist secara mulus untuk server Online-Mode, Offline/Cracked,
 * maupun Bedrock/Geyser dengan pesan kick kustom yang mengarahkan ke Discord.
 */
public class WhitelistLoginListener implements Listener {

    private final DiscordWhitelistPlugin plugin;

    public WhitelistLoginListener(DiscordWhitelistPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerLogin(PlayerLoginEvent event) {
        Player player = event.getPlayer();
        boolean registeredHere = plugin.getWhitelistManager().isWhitelisted(player.getName());

        // Jika terdaftar di DiscordAutoWhitelist -> selalu izinkan masuk (bahkan jika vanilla gagal lookup UUID offline/Bedrock!)
        if (registeredHere || player.isOp() || player.hasPermission("discordwhitelist.admin")) {
            if (event.getResult() == PlayerLoginEvent.Result.KICK_WHITELIST) {
                event.allow();
            }
            return;
        }

        // Jika server whitelist aktif dan pemain belum terdaftar -> tampilkan pesan kick Discord
        if (Bukkit.hasWhitelist() || event.getResult() == PlayerLoginEvent.Result.KICK_WHITELIST) {
            event.disallow(PlayerLoginEvent.Result.KICK_WHITELIST, plugin.getFormattedKickMessage());
        }
    }
}
