package com.discordwhitelist;

import com.discordwhitelist.discord.DiscordBotManager;
import com.discordwhitelist.listener.WhitelistLoginListener;
import com.discordwhitelist.manager.WhitelistManager;
import com.discordwhitelist.util.ColorUtil;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class DiscordWhitelistPlugin extends JavaPlugin {

    private WhitelistManager whitelistManager;
    private DiscordBotManager discordBot;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        if (getConfig().getBoolean("whitelist.auto-enable-server-whitelist", true)) {
            Bukkit.setWhitelist(true);
        }

        this.whitelistManager = new WhitelistManager(this);
        this.discordBot = new DiscordBotManager(this);

        getServer().getPluginManager().registerEvents(new WhitelistLoginListener(this), this);

        this.discordBot.startAsync();
        getLogger().info("DiscordAutoWhitelist v" + getDescription().getVersion() + " aktif (100% via Discord)!");
    }

    @Override
    public void onDisable() {
        if (discordBot != null) {
            discordBot.shutdown();
        }
        if (whitelistManager != null) {
            whitelistManager.save();
        }
    }

    public WhitelistManager getWhitelistManager() {
        return whitelistManager;
    }

    public DiscordBotManager getDiscordBot() {
        return discordBot;
    }

    public String getFormattedKickMessage() {
        String invite = getConfig().getString("whitelist.discord-invite", "discord.gg/serverkamu");
        String raw = getConfig().getString("messages.kick-not-whitelisted",
                "&cKamu belum terverifikasi whitelist! Daftar di Discord: &b%invite%");
        return ColorUtil.color(raw.replace("%invite%", invite));
    }
}
